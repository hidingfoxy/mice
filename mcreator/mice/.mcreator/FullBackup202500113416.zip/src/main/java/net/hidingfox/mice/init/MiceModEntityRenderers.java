
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.hidingfox.mice.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.hidingfox.mice.client.renderer.WoollyMouseRenderer;
import net.hidingfox.mice.client.renderer.RatRenderer;
import net.hidingfox.mice.client.renderer.MouseRenderer;
import net.hidingfox.mice.client.renderer.JerboaRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MiceModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MiceModEntities.MOUSE.get(), MouseRenderer::new);
		event.registerEntityRenderer(MiceModEntities.RAT.get(), RatRenderer::new);
		event.registerEntityRenderer(MiceModEntities.JERBOA.get(), JerboaRenderer::new);
		event.registerEntityRenderer(MiceModEntities.WOOLLY_MOUSE.get(), WoollyMouseRenderer::new);
	}
}
