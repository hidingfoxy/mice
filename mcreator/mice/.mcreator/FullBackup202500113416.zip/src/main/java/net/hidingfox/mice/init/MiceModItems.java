
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.hidingfox.mice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;

import net.hidingfox.mice.MiceMod;

public class MiceModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MiceMod.MODID);
	public static final RegistryObject<Item> MOUSE_SPAWN_EGG = REGISTRY.register("mouse_spawn_egg", () -> new ForgeSpawnEggItem(MiceModEntities.MOUSE, -10269889, -10003881, new Item.Properties()));
	public static final RegistryObject<Item> RAT_SPAWN_EGG = REGISTRY.register("rat_spawn_egg", () -> new ForgeSpawnEggItem(MiceModEntities.RAT, -11844283, -16185336, new Item.Properties()));
	public static final RegistryObject<Item> JERBOA_SPAWN_EGG = REGISTRY.register("jerboa_spawn_egg", () -> new ForgeSpawnEggItem(MiceModEntities.JERBOA, -13210, -10003881, new Item.Properties()));
	public static final RegistryObject<Item> WOOLLY_MOUSE_SPAWN_EGG = REGISTRY.register("woolly_mouse_spawn_egg", () -> new ForgeSpawnEggItem(MiceModEntities.WOOLLY_MOUSE, -8955073, -10003881, new Item.Properties()));
	// Start of user code block custom items
	// End of user code block custom items
}
