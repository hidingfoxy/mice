package net.hidingfox.mice.procedures;

public class MousePlaybackConditionProcedure {
	public static boolean execute() {
		return true;
	}
}
