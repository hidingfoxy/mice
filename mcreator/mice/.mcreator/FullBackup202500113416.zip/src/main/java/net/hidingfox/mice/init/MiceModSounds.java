
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.hidingfox.mice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.hidingfox.mice.MiceMod;

public class MiceModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MiceMod.MODID);
	public static final RegistryObject<SoundEvent> ENTITY_MOUSE_SQUEAKS = REGISTRY.register("entity.mouse.squeaks", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("mice", "entity.mouse.squeaks")));
	public static final RegistryObject<SoundEvent> ENTITY_MOUSE_HURTS = REGISTRY.register("entity.mouse.hurts", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("mice", "entity.mouse.hurts")));
	public static final RegistryObject<SoundEvent> ENTITY_RAT_SQUEAKS = REGISTRY.register("entity.rat.squeaks", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("mice", "entity.rat.squeaks")));
	public static final RegistryObject<SoundEvent> ENTITY_RAT_HURT = REGISTRY.register("entity.rat.hurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("mice", "entity.rat.hurt")));
	public static final RegistryObject<SoundEvent> ENTITY_JERBOA_SQUEAKS = REGISTRY.register("entity.jerboa.squeaks", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("mice", "entity.jerboa.squeaks")));
	public static final RegistryObject<SoundEvent> ENTITY_JERBOA_HURT = REGISTRY.register("entity.jerboa.hurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("mice", "entity.jerboa.hurt")));
}
