
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.hidingfox.mice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.hidingfox.mice.entity.WoollyMouseEntity;
import net.hidingfox.mice.entity.RatEntity;
import net.hidingfox.mice.entity.MouseEntity;
import net.hidingfox.mice.entity.JerboaEntity;
import net.hidingfox.mice.MiceMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MiceModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MiceMod.MODID);
	public static final RegistryObject<EntityType<MouseEntity>> MOUSE = register("mouse",
			EntityType.Builder.<MouseEntity>of(MouseEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(16).setUpdateInterval(3).setCustomClientFactory(MouseEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<RatEntity>> RAT = register("rat",
			EntityType.Builder.<RatEntity>of(RatEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(16).setUpdateInterval(3).setCustomClientFactory(RatEntity::new)

					.sized(0.3f, 0.5f));
	public static final RegistryObject<EntityType<JerboaEntity>> JERBOA = register("jerboa",
			EntityType.Builder.<JerboaEntity>of(JerboaEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(16).setUpdateInterval(3).setCustomClientFactory(JerboaEntity::new)

					.sized(0.3f, 0.3f));
	public static final RegistryObject<EntityType<WoollyMouseEntity>> WOOLLY_MOUSE = register("woolly_mouse",
			EntityType.Builder.<WoollyMouseEntity>of(WoollyMouseEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(16).setUpdateInterval(3).setCustomClientFactory(WoollyMouseEntity::new)

					.sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			MouseEntity.init();
			RatEntity.init();
			JerboaEntity.init();
			WoollyMouseEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(MOUSE.get(), MouseEntity.createAttributes().build());
		event.put(RAT.get(), RatEntity.createAttributes().build());
		event.put(JERBOA.get(), JerboaEntity.createAttributes().build());
		event.put(WOOLLY_MOUSE.get(), WoollyMouseEntity.createAttributes().build());
	}
}
