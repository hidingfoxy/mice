
package net.hidingfox.mice.client.renderer;

import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.hidingfox.mice.procedures.MousePlaybackConditionProcedure;
import net.hidingfox.mice.procedures.MouseModelVisualScaleProcedure;
import net.hidingfox.mice.entity.MouseEntity;
import net.hidingfox.mice.client.model.animations.mouseAnimation;
import net.hidingfox.mice.client.model.Modelmouse;

import com.mojang.blaze3d.vertex.PoseStack;

public class MouseRenderer extends MobRenderer<MouseEntity, Modelmouse<MouseEntity>> {
	public MouseRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelmouse.LAYER_LOCATION)), 0.3f);
	}

	@Override
	protected void scale(MouseEntity entity, PoseStack poseStack, float f) {
		Level world = entity.level();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		float scale = (float) MouseModelVisualScaleProcedure.execute(entity);
		poseStack.scale(scale, scale, scale);
	}

	@Override
	public ResourceLocation getTextureLocation(MouseEntity entity) {
		return new ResourceLocation("mice:textures/entities/mousetexture.png");
	}

	private static final class AnimatedModel extends Modelmouse<MouseEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<MouseEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(MouseEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				if (MousePlaybackConditionProcedure.execute())
					this.animateWalk(mouseAnimation.walk, limbSwing, limbSwingAmount, 4f, 5f);
				this.animate(entity.animationState1, mouseAnimation.run, ageInTicks, 4f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(MouseEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
